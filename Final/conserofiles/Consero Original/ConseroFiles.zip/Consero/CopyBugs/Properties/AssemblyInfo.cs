﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using FogCreek.Plugins;

//Fogbugz Attributes
[assembly: AssemblyFogCreekPluginIdAttribute("CopyBugs@conseroglobal.com")]
[assembly: AssemblyFogCreekMajorVersionAttribute(3)]
[assembly: AssemblyFogCreekMinorVersionMinAttribute(5)]
[assembly: AssemblyFogCreekEmailAddressAttribute("econsero@conseroglobal.com")]
[assembly: AssemblyFogCreekWebsiteAttribute("http://www.conseroglobal.com")]
[assembly: AssemblyTitle("CopyBugs")]
[assembly: AssemblyDescription("Copy Bugs.")]
[assembly: AssemblyCompany("Consero Global Solutions")]
[assembly: AssemblyVersion("1.0.0.0")]