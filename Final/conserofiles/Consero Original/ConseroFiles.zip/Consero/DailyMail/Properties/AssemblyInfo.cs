﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using FogCreek.Plugins;

//Fogbugz Attributes
[assembly: AssemblyFogCreekPluginIdAttribute("DailyMail@conseroglobal.com")]
[assembly: AssemblyFogCreekMajorVersionAttribute(3)]
[assembly: AssemblyFogCreekMinorVersionMinAttribute(5)]
[assembly: AssemblyFogCreekEmailAddressAttribute("econsero@conseroglobal.com")]
[assembly: AssemblyFogCreekWebsiteAttribute("http://www.conseroglobal.com")]
[assembly: AssemblyTitle("DailyMail")]
[assembly: AssemblyDescription("Post Daily Mail to Consero Clients.")]
[assembly: AssemblyCompany("Consero Global Solutions")]
[assembly: AssemblyVersion("1.0.0.0")]