﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using FogCreek.Plugins;

//Fogbugz Attributes
[assembly: AssemblyFogCreekPluginIdAttribute("PostToIntacct@conseroglobal.com")]
[assembly: AssemblyFogCreekMajorVersionAttribute(3)]
[assembly: AssemblyFogCreekMinorVersionMinAttribute(5)]
[assembly: AssemblyFogCreekEmailAddressAttribute("econsero@conseroglobal.com")]
[assembly: AssemblyFogCreekWebsiteAttribute("http://www.conseroglobal.com")]
[assembly: AssemblyTitle("PostToIntacct")]
[assembly: AssemblyDescription("Post To Intacct For Consero Clients.")]
[assembly: AssemblyCompany("Consero Global Solutions")]
[assembly: AssemblyVersion("1.0.0.0")]